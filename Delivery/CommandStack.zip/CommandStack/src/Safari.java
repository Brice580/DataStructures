import java.util.Scanner;

/**
 * This class represents the Safari command for maps with string methods for printing and valid command method for
 * checking validity
 *
 * @author Brice Joseph, 114588946, R03
 *
 */

public class Safari extends Application{

    /**
     * Public constructor for the command
     * Postcondition:
     * Command is created
     */
    public Safari(){

    }

}
